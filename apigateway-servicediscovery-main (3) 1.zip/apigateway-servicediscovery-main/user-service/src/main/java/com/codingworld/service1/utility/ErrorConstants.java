package com.codingworld.service1.utility;

public class ErrorConstants {
}
