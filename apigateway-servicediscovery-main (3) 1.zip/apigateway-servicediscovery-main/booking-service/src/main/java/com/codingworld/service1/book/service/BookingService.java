package com.codingworld.service1.book.service;

import com.codingworld.service1.book.modal.Book;

import java.util.List;

public interface BookingService {
    Book addFlight(Book flight,String name);
    List<Book> getAllFlight();
    Book findById(Long id);
    void deleteFlightById(Long id);
}
