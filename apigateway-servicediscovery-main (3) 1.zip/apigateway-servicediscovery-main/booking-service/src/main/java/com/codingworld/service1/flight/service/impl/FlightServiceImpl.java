package com.codingworld.service1.flight.service.impl;

import com.codingworld.service1.flight.modal.Flight;
import com.codingworld.service1.flight.repository.FlightRepository;
import com.codingworld.service1.flight.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
@Service
public class FlightServiceImpl implements FlightService {

    @Autowired
    private FlightRepository flightRepository;

    @Override
    public Flight addFlight(Flight flight) {
        return flightRepository.save(flight);
    }

    @Override
    public List<Flight> getAllFlight() {
        return Collections.emptyList();
    }

    @Override
    public Flight findById(Long id) {
        return null;
    }

    @Override
    public void deleteFlightById(Long id) {

    }
}
