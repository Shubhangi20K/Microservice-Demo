package com.codingworld.service1.flight.controller;

import com.codingworld.service1.flight.modal.Flight;
import com.codingworld.service1.flight.service.FlightService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("flight")
public class FlightController {

    Logger logger= LoggerFactory.getLogger(FlightController.class);
    @Autowired
    private FlightService flightService;

    @GetMapping("/home")
    public String FlightController(){
        logger.info("FlightController test");
        return "FlightController service is working";
    }

    @PostMapping("/add")
    public Flight add(@RequestBody Flight flight) {
        logger.info("FlightController is execute {}",flight);
        return flightService.addFlight(flight);
    }

    @GetMapping("/{id}")
    public Flight getFlightById(@PathVariable Long id) {
        logger.info("FlightController is execute getFlightById",id);
        return flightService.findById(id);
    }


    @GetMapping("/all")
    public List<Flight> getAllFlight() {
        logger.info("FlightController is execute getAllFlight");
        return flightService.getAllFlight();
    }

    @DeleteMapping("/delete/{id}")
    public void deleteFlight(@PathVariable Long id) {
        logger.info("FlightController is execute deleteFlight");
        flightService.deleteFlightById(id);
    }
}
