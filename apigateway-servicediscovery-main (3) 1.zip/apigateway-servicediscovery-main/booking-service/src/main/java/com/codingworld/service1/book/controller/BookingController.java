package com.codingworld.service1.book.controller;

import com.codingworld.service1.book.modal.Book;
import com.codingworld.service1.book.service.BookingService;
import com.codingworld.service1.comman.dto.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/book")
public class BookingController {

    Logger logger= LoggerFactory.getLogger(BookingController.class);

    @Autowired
    private BookingService flightService;

    @Autowired
    private RestTemplate restTemplate;




    @GetMapping("/home")
    public String bookingController(@RequestHeader("loggedInUser") String name){
        logger.info("BookingServiceImpl class {} ",name);
        try {
            String user = restTemplate.getForObject("http://localhost:9002/api/user/test", String.class);
            System.out.println(user);
        }catch (Exception ex){
            logger.error("error in fetch user {}",ex);
        }

        logger.info("BookingController test"+name);
        return "BookingController service is working "+name;
    }

    @PostMapping("/add")
    public Book add(@RequestBody Book flight,@RequestHeader("loggedInUser") String name) {
        logger.info("FlightController is execute {} and {}",flight,name);
        return flightService.addFlight(flight,name);
    }

    @GetMapping("/{id}")
    public Book getFlightById(@PathVariable Long id) {
        logger.info("FlightController is execute getFlightById",id);
        return flightService.findById(id);
    }


    @GetMapping("/all")
    public List<Book> getAllFlight() {
        logger.info("FlightController is execute getAllFlight");
        return flightService.getAllFlight();
    }

    @DeleteMapping("/delete/{id}")
    public void deleteFlight(@PathVariable Long id) {
        logger.info("FlightController is execute deleteFlight");
        flightService.deleteFlightById(id);
    }
}
